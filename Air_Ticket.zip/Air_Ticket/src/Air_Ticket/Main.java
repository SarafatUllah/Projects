package Air_Ticket;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Main {
    public static void main(String[] args) throws SQLException {
//         MyDatabaseHandler db = new MyDatabaseHandler();
//         db.connectDatabase();
//         db.insertData();
//         ResultSet rs = db.testQuery();
//         db.showResult(rs); 
       // View view=new View();
       // view.show();
       
     //  Passenger_Registration p_info=new Passenger_Registration();
     //  p_info.setBounds(0,0,450,490);
      
     //  p_info.setVisible(true);
      Ticket_View tv=new Ticket_View();
      tv.setVisible(true);
    }
    
}
