CREATE TABLE Properties
(
PropertyId int IDENTITY(1,1) PRIMARY KEY,
Type varchar(50) NOT NULL,
Status varchar(50) NOT NULL,
Address varchar(200) NULL  DEFAULT  'Dhaka',
)

INSERT INTO Properties (Type, Status, Address )
VALUES ('Residential','Completed', 'Dhaka')
	  

ALTER TABLE properties DROP COLUMN test;

select *from Properties
drop table Properties

CREATE TABLE ProjectAppartment
(
ProjectID int IDENTITY(1,1) PRIMARY KEY,
Name varchar(50) NOT NULL,
Address varchar(200) NOT NULL ,
ProjectManager varchar(200) NOT NULL ,
Contact int NOT NULL,
PropertyId int NOT NULL FOREIGN KEY REFERENCES Properties(PropertyId),
)

select* from ProjectAppartment

INSERT INTO ProjectAppartment (Name, Address, ProjectManager, Contact,PropertyId )
VALUES ('Himadri2','Dhaka', 'Shakil', 0152110989,19)
     
	  
	  select*from ProjectAppartment 

	  
CREATE TABLE Appartment
(
ApID int IDENTITY(1,1) PRIMARY KEY,
floor varchar(100) NOT NULL,
Area varchar(100) NOT NULL,
Beds int NOT NULL ,
Baths int NOT NULL ,
garage int NOT NULL,
ProjectID int NOT NULL FOREIGN KEY REFERENCES ProjectAppartment(ProjectID)

)

INSERT INTO Appartment(Floor,Area, Beds, Baths, garage , ProjectID)
VALUES ('2nd','2000 sqft', 4, 4, 3, 9)
     
	 select* from Appartment

drop table Appartment

CREATE TABLE ProjectCommercial
(
ProjectID int IDENTITY(1,1) PRIMARY KEY,
Name varchar(50) NOT NULL,
Address varchar(200) NOT NULL ,
ProjectManager varchar(200) NOT NULL ,
Contact int NOT NULL,
PropertyId int NOT NULL FOREIGN KEY REFERENCES Properties(PropertyId),
)
select* from ProjectCommercial
INSERT INTO ProjectCommercial(Name, Address, ProjectManager, Contact,PropertyId )
VALUES ('amtola','Dhaka', 'Shakil', 0152110989,1),
       ('jamtola','Dhaka', 'farid', 02087364,3)

drop table ProjectCommercial

select * from ProjectCommercial
CREATE TABLE Commercial
(
CpmmercialID int IDENTITY(1,1) PRIMARY KEY,
Floor varchar(28) NOT NULL,
area float NOT NULL,
Baths float NOT NULL ,
garage float NOT NULL ,
ProjectID int NOT NULL FOREIGN KEY REFERENCES ProjectCommercial(ProjectID),
)
drop table Commercial

ALTER TABLE Commercial
ALTER COLUMN area varchar;
INSERT INTO Commercial(Floor,area, baths, garage )
VALUES ('3rd',3211,12,20)
     

drop table Commercial
select * from commercial

CREATE TABLE ProjectIndustrial
(
ProjectID int IDENTITY(1,1) PRIMARY KEY,
Name varchar(50) NOT NULL,
Address varchar(200) NOT NULL ,
ProjectManager varchar(200) NOT NULL ,
Contact int NOT NULL,
PropertyId int NOT NULL FOREIGN KEY REFERENCES Properties(PropertyId),
)


drop table ProjectIndustrial
select  * from ProjectIndustrial
INSERT INTO ProjectIndustrial(Name, Address, ProjectManager, Contact,PropertyId )
VALUES ('pran','Dhaka', 'Shakil', 0152110989,1),
       ('meghna','Dhaka', 'farid', 02087364,3)

CREATE TABLE Industrial
(
IndustrialID int IDENTITY(1,1) PRIMARY KEY,
floor int,
area int NOT NULL,
Baths int NOT NULL,
garage int NOT NULL ,
ProjectID int NOT NULL FOREIGN KEY REFERENCES ProjectIndustrial(ProjectID),
)
INSERT INTO Industrial(floor, area, Baths, garage, ProjectID )
VALUES (4, 12000,10, 4, 1)
       
	   select * from Industrial
	   drop table Industrial;

CREATE TABLE Clients
(
ClientId int IDENTITY(1,1) PRIMARY KEY,
Name varchar(50) NOT NULL,
Age int NOT NULL CHECK (Age >= 18),
Address varchar(200) NOT NULL,
Email varchar(200) NULL,
Phone int,

)
drop table Clients
select * from clients


INSERT INTO Clients(Name, age, Address, Email, phone )
VALUES ('Mr Akash',43, 'dhaka','akash@gmail.com', 0152110989 ),
       ('Mr Badol',39, 'dhaka','badol@gmail.com', 015211098 )


CREATE TABLE Payment
(
PaymentId int IDENTITY(1,1) PRIMARY KEY,
ClientId int,
DownPayment float,
Due int,
date date
)



CREATE TABLE Payment
(
PaymentId int IDENTITY(1,1) PRIMARY KEY,
Total int,
DownPayment float,
Due int,
Interest float,
ClientId int NOT NULL FOREIGN KEY REFERENCES Clients(ClientId)
)
drop table Payment

INSERT INTO payment( Total, DownPayment,Due, interest, ClientId )
VALUES (320000,19000, 12000,8,1)
  
  alter table payment
	   ALTER COLUMN DownPayment int;

select*from payment

CREATE TABLE Employee
(
EmployeeId int IDENTITY(1,1) PRIMARY KEY,
FirstName varchar(50) NOT NULL,
LasstName varchar(50) NOT NULL,
Age int NOT NULL CHECK (Age >= 18),
Address varchar(200) NOT NULL,
Email varchar(200) NULL,
Phone int,
salary varchar(30) NOT NULL
)
ALTER TABLE Employee drop column salary ;
INSERT INTO Employee(FirstName,LasstName, age, Address, Email, phone, Salary )
VALUES ('Mr Akash', 'Mridha',43, 'dhaka','akash@gmail.com', 0152110989, '19000'),
       ('Mr Badol','Haque ',39, 'dhaka','badol@gmail.com', 0152110989, '20000')

drop table Clinets

select * from Employee