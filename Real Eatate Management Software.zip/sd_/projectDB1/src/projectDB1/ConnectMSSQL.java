
package projectDB1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;


public class ConnectMSSQL {
    
     public Connection connection;
     public String adminPass ;
     public String adminID;
     Statement state;
    public void connectDB() {
                
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            connection = DriverManager.getConnection(
                    "jdbc:sqlserver://localhost:1433;databaseName=projectDB1;selectMethod=cursor", "sa", "123456");

            System.out.println("DATABASE NAME IS:" + connection.getMetaData().getDatabaseProductName());

             state = connection.createStatement();
            
           String sqlid = "Select adminId FROM admin";
           String sql  = "Select AdminPass FROM admin";
          //  System.out.println("sakib");
           // String sql1 = "Select LastName FROM Customer";
            //String sql2 = "Select CustomerAddress FROM Customer";
            
      //      System.out.println("sakib");
      
       ////////////////////////////////   String sqlAdminInfo = "Select FirstName FROM AdminInfo";
            
             ResultSet rs = state.executeQuery(sql);
                  
       /*      
             
             StringBuilder builder = new StringBuilder();
             
             while (rs.next()){
                  builder.append(sql);
                  
                 
             }
             String all = builder.toString();
             
             System.out.println(all);
             
             */
          //   System.out.println("sa1");
          //   ResultSet rs1 = statement.executeQuery(sql1);
         //    ResultSet rs2 = statement.executeQuery(sql2);
        
           while ( rs.next() ) {
               // String first =rs.getString("FirstName");
               // String last =rs.getString("LastName");
                this.adminPass = rs.getString("AdminPass");
                
              //  System.out.print(" First: " + first);
              //  System.out.println(" Last: " + last);   
            
            //   System.out.println(" AdminPass: " + adminPass);   
          //     System.out.println("id: "+adminId);
              
                
            }
           
           
           ResultSet rs1 = state.executeQuery(sqlid);
            
             System.out.println("sssssss");
            while(rs1.next()){
               
               this.adminID = rs1.getString("adminId");
            //   System.out.println("adminID: "+ adminID);
           }
             
        
        
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    
    
 /*
    public  String gettingPass(){
        NewJFrame n = new NewJFrame();
      String p =    n.getPass();
      return p;   
       }    
    
    public  String gettingAdmin(){
        NewJFrame n = new NewJFrame();
        
          String a = n.getAdmin();
          return a;
    }    
   */
    
 public static void main(String[] args) {
    
     ConnectMSSQL con = new ConnectMSSQL();
     con.connectDB();
  
     
  // con.gettingPass();
     
    }
}