package projectDB1;

import javax.swing.JOptionPane;


public class signIn extends javax.swing.JFrame {

     boolean myint;
  
    public signIn() {
     // setLocationRelativeTo(null);
      setResizable(false);
      initComponents();
     // setDefaultCloseOperation(NewJFrame.EXIT_ON_CLOSE);
    
      
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        logBut = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        userinput = new javax.swing.JTextField();
        output = new javax.swing.JPasswordField();
        clearBut = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        jButton1.setText("jButton1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setAlwaysOnTop(true);

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));

        logBut.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        logBut.setText("LogIn");
        logBut.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                logButActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        jLabel2.setText("Admin ID");

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        jLabel3.setText("Password");

        userinput.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N

        output.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        output.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                outputActionPerformed(evt);
            }
        });

        clearBut.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        clearBut.setText("Clear");
        clearBut.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clearButActionPerformed(evt);
            }
        });

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/projectDB1/img.jpg"))); // NOI18N

        jButton2.setText("set");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(175, 175, 175)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel3)
                    .addComponent(jLabel2))
                .addGap(80, 80, 80)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(logBut)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 40, Short.MAX_VALUE)
                        .addComponent(clearBut)
                        .addGap(9, 9, 9))
                    .addComponent(userinput)
                    .addComponent(output))
                .addGap(60, 60, 60)
                .addComponent(jButton2)
                .addContainerGap(164, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 290, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 259, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(61, 61, 61)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(userinput, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(16, 16, 16)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(output, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(43, 43, 43)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(logBut)
                    .addComponent(clearBut)
                    .addComponent(jButton2))
                .addContainerGap(96, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents
 String id ;
       String pass;
       
    private void logButActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_logButActionPerformed
      
        id = userinput.getText().toString();
        pass = output.getText().toString();
        
        output.setText(userinput.getText());
        System.out.println(id);
      ConnectMSSQL con = new ConnectMSSQL();
       con.connectDB();
     //  String passInput = passF.getText();  // getting password from password field
    //   String idInput = adminF.getText();   // getting adminId from adminID text field
        
  
    
       signIn n = new signIn();
      
       String passDatab = con.adminPass;    // passing password of admin from database
       String adminId = con.adminID;        // passing adminID from databse
       
      /* if(passInput.equals(passDatab)  && idInput.equals(adminId)){
           new loggedIn().setVisible(true);
         
           dispose();
       } */
       
        System.out.println("imput id "+ userinput.getText());
         System.out.println(" input pass"+pass);
        System.out.println("fetch id "+ adminId);
         System.out.println(" fetch pass"+passDatab);
         
         
      if(pass.equals(passDatab) && id.equals(adminId)){
          loggedIn log = new loggedIn();
          log.setVisible(true);
      }
       else{
           JOptionPane.showMessageDialog(n,"Wrong Password or AdminID");  
           userinput.setText(null);
           output.setText(null);
       //    System.out.println(passDatab);
        //   System.out.println(adminId);
       }
       // dispose();
        
  
    }//GEN-LAST:event_logButActionPerformed

    private void outputActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_outputActionPerformed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_outputActionPerformed

    private void clearButActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clearButActionPerformed
        // TODO add your handling code here:
        userinput.setText(null);
        output.setText(null);
    }//GEN-LAST:event_clearButActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        
       
    }//GEN-LAST:event_jButton2ActionPerformed

    
   
  //  private String number;
    
  /*   public String getAd() {
        return this.s;
    }
 
    public void setNumber(int num) {
        this.number = num;
    }
    
    */
    /*
    public String getPass(){
     
     String pass = passF.getText();
     System.out.println("sssss");
     
     return pass;
       
     
    }
    
    public String getAdmin(){
        String admin = adminF.getText();
        return admin;
    }
    */
    public static void main(String args[]) {
      
        
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
              //  new NewJFrame().setVisible(true);
               signIn newFrame = new signIn();
               newFrame.setVisible(true);
               newFrame.initComponents();
               
       
            }
        });
    
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton clearBut;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JButton logBut;
    private javax.swing.JPasswordField output;
    private javax.swing.JTextField userinput;
    // End of variables declaration//GEN-END:variables

    
}
